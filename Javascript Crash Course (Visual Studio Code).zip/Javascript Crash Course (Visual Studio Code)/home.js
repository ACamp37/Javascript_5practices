// Console.log is same as System.out.print or println.
console.log('hello');

//alert ('hello this is Qazi');

// How to write a comment inline 

// Variables 
var b = 'smoothie';
console.log(b);

var someNumber = 45;
console.log(someNumber);

// var age = prompt('What is your age?');

// document.getElementById('someText').innerHTML = age;

// Numbers in Javascript (15:50)
var num1 = 10;

// Increment num1 by 1
num1++;

// Decrement num1 by 1
num1--;

// Divide /, multiply *, remainder %
console.log(num1 % 6);

// Increment/decrement by 10
num1 += 10;
console.log(num1);

/* Functions
1. Create a function 
2. Call the function
*/

// Create
function fun(){
    console.log('this is a function');
}

// Call
fun();

/* Let's create a function that takes in a name
and says hello followed by your name

For example

Name: Qazi
Return: "Hello Qazi"
*/

// function greeting(){
    // var name = prompt('What is your name?');
    // var result = 'Hello' + ' ' + name; //String Concatenation
    // console.log(result);
// }

//Testing an override below with 1 parameter instead of none. This
//was attempted in the early tutorial, but I choose to keep the same
// method with empty params above. Aaron is trying this
function greeting(yourName){
    var result = 'Hello' + ' ' + yourName;
    console.log(result);
}

// var name = prompt('What is your name again?');
// greeting();
// greeting(name); 

// How do arguments work in functions?
// How do we add 2 numbers together in a function? 

function sumNumbers(num1, num2){
    var result = num1 + num2;
    console.log(num1 + num2);
}

sumNumbers(10, 10);

// sumNumbers('10 ', 10); 
// Notice above we didn't enforce a data type here. Vars
// in Javascript work different from variable data types from Java where
// we need to specify String or int or any other data type/Object type

/* While loops
var num = 0;

while(num < 100){
    num += 1;
    console.log(num);
}

*/


// For loops: Does the same thing as the while loop above.  
for(let num = 0; num<=100; num++ ){ //let is very similar to var. Will see slight different over time
    console.log(num);
}

// Data types
// var yourAge = 18; 
let yourAge = 18; //Number
let yourName = 'Bob'; //String
let name = {first: 'jane', last: 'Doe'}; //Object
let truth = false; //Boolean
let groceries = ['apple', 'banana', 'oranges']; //Array
let random; //undefined --> can't have in Java to my understanding
let nothing = null; //value null

// Strings in Javascript (common methods)
let fruit = 'banana,apple,orange,blackberry';
let moreFruits = 'banana\napple'; // new line --> \n
console.log(moreFruits);

console.log(fruit.length); // counting length of fruit (banana)
console.log(fruit.indexOf('a'));
console.log(fruit.indexOf('nan'));
console.log(fruit.slice(2, 6));
console.log(fruit.replace('ban', '123'));
console.log(fruit.toUpperCase());
console.log(fruit.toLowerCase());
console.log(fruit.charAt(2));
console.log(fruit[2]);
console.log(fruit.split(',')); // remember this is split by a comma
console.log(fruit.split('')); //split by characters

// Array
let fruits = ['banana', 'apple', 'orange', 'pineapples'];
fruits = new Array ('banana', 'apple', 'orange', 'pineapples'); // Alternative way of doing array

console.log(fruits[2]); //access value at index 2nd (orange in this case)

fruits[0] = 'pear'; //change value at index 0 from banana to pear 
console.log(fruits);

for(let i = 0; i < fruits.length; i++){
    console.log(fruits[i]); //looping through arrays. Printing them all out here
}

// Array common methods
console.log('to string', fruits.toString());
console.log(fruits.join(' - '));
console.log(fruits.join(' * '));
console.log(fruits.pop(), fruits); //pops off the last element (pineapples) and then returns it to you. Deletes
console.log(fruits.push('blackberries'), fruits); //pushed on the last element and then returns it to you. Appends/add
console.log(fruits[4]);
fruits[4] = 'new fruit';
// fruits[fruits.length] = 'new fruit'; //same as push and same as line above
console.log(fruits)
fruits.shift(); //removes first element from a array. No really friendly and advised, but possible
console.log(fruits) //Note to self: Do I not need a semicolon at the end? 
fruits.unshift('kiwi'); //add first element to an array
console.log(fruits)

let vegetables = ['asparagus', 'tomato', 'broccoli'];
let allGroceries = fruits.concat(vegetables); //Works like a join
console.log(allGroceries);
console.log(allGroceries.slice(1, 4)); //Slice from 1 - 4 (including 4)
console.log(allGroceries.reverse()); //reverses the array
console.log(allGroceries.sort()); //Will sort the order of the array

let someNumbers = [5, 10, 2, 25, 3, 255, 1, 2, 5, 334, 321, 2];
console.log(someNumbers.sort(function(a, b) {return a-b})); //Will sort the order of the array for numbers ascending
console.log(someNumbers.sort(function(a, b) {return b-a})); //Will sort the order of the array for numbers descending

let emptyArray = new Array();

for(let num = 0; num < 10; num++){ //Gonna make a for loop to add things to the emptyArray
    emptyArray.push(num);
}
console.log(emptyArray); 

let aaronCanIDoThis = ['String', 1]; //Testing to see here if I can mix data types since let/var isnt directly assigned
console.log(aaronCanIDoThis);
 
// Objects in Javascript. Just like Java (these are called dictonaries in Python)
let student = {
    first: 'Rafeh', 
    last: 'Qazi',
    age:25, 
    height:170,
    studentInfo: function(){
        return this.first + '\n' + this.last + '\n' + this.age;
    }
};

// console.log(student.first);
// console.log(student.last);
// student.first = 'notRafeh'; //Changing the value, reassigning from Rafeh to notRafeh
// console.log(student.first);
student.age++; //Increment age by 1, 25 --> 26
console.log(student.age);

console.log(student.studentInfo()); //Calling the function from above

// Conditionals, Control flows (if else)
// 18-35 is my target demographic
// var age = prompt('what is your age?'); //let doesn't seem to like prompt. Using var
var age = 45;

if((age >= 18) && (age<=35)){
    status = 'target demo';
    console.log(status);
} else {
    status = 'not my audience';
    console.log(status);
}

// Switch statements:
// differentiate between weekday vs. weekend
// Day 0 --> Sunday --> weekend
// Day 1 --> Monday  --> weekday 
// Day 2 --> Tuesday --> weekday
// Day 3 --> Wednesday --> weekday 
// Day 4 --> Thursday --> weekday 
// Day 5 --> Friday --> weekend
// Day 6 --> Saturday --> weekend
switch(6){
    case 0:
        text = 'weekend';
        break;
    case 5:
        text = 'weekend';
        break;
    case 6:
        text = 'weekend';
        break;
    default: 
        text = 'weekday';
}

console.log(text);

//LEFT OFF AT 1:36:45 OF VIDEO JUST FOR REFERENCE AARON!!!!!!!.